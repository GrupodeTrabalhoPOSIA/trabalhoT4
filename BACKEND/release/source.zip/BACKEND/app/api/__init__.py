"""Rotas HTTP da aplicação."""

